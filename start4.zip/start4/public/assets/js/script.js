
var table = document.getElementById('table');
var elenco = [];

window.addEventListener('DOMContentLoaded', init);
function init() {
    printData();
}

function printData() {
    //se ad una fetch non viene passato nessun paramentro, quello standard è il metodo get
    //la fetch è una Promise e ogni then è una Promise che si esegue a cascata
    fetch('https://jsonplaceholder.typicode.com/users').then((response) => {
        return response.json(); //trasforma la stringa in un json 
    }).then((data) => {
        elenco = data; //nell'array vanno i dati che arrivano da response.json()
        if (elenco.length > 0) {
            table.innerHTML = '';
            elenco.map(function (element) {
                table.innerHTML += `<tr><td>${element.name}</td><td>${element.username}</td><td>${element.email}</td><td>${element.website}</td><td>${element.company.name}</td></tr>`
            })
        }
    })
}